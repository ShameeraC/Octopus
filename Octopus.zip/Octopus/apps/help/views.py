from django.shortcuts import render

def help(request):
    return render(request, 'help\\Help_Page.html')

def reference(request):
    return render(request, 'help\\References.html')
