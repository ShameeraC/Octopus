from django.urls import path

from apps.help.views import help, reference

urlpatterns = [
    path('help/', help, name="help"),
    path('references/', reference, name="reference")
]
