from django.urls import path

from apps.recycling.views import recyclingdash, recycleplastic, recyclepaper, recycleglass, recyclemetal

urlpatterns = [
    path('', recyclingdash, name="recyclingdash"),
    path('plastic/', recycleplastic, name="recycleplastic"),
    path('paper/', recyclepaper, name="recyclepaper"),
    path('glass/', recycleglass, name="recycleglass"),
    path('metal/', recyclemetal, name="recyclemetal"),
]
