from django.shortcuts import render

def recyclingdash(request):
    return render(request, 'recycling\\base.html')

def recycleplastic(request):
    return render(request,'recycling\\plastic.html')

def recyclepaper(request):
    return render(request,'recycling\\paper.html')

def recycleglass(request):
    return render(request,'recycling\\glass.html')

def recyclemetal(request):
    return render(request,'recycling\\metal.html')