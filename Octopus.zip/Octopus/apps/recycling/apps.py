from django.apps import AppConfig


class RecyclingConfig(AppConfig):
    name = 'recycling'
