from django.contrib import admin
from apps.community.models import Tip

admin.site.register(Tip)
