from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect

from apps.community.models import Tip
from apps.community.forms import TipForm

def community(request):
    tips = Tip.objects.all()

    context = {
        'tips': tips
    }

    return render(request, 'community\\alltips.html', context)

@login_required
def tip_add(request):
    if request.method == 'POST':
        form = TipForm(request.POST)

        if form.is_valid():
            title = form.cleaned_data['title']
            info = form.cleaned_data['info']
            user = request.user
            p = Tip(title=title, info=info, created_by=user)
            p.save()

            return redirect('community')
    else:
        form = TipForm()

    context = {
        'form': form
    }

    return render(request, 'community\\tip_add.html', context)
