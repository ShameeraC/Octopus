from django.apps import AppConfig


class CarbonConfig(AppConfig):
    name = 'carbon'
