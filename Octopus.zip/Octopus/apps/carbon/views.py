from django.shortcuts import render

def carbon(request):
    return render(request, 'carbon\\practice.html')
