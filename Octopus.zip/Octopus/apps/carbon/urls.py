from django.urls import path

from apps.carbon.views import carbon

urlpatterns = [
    path('', carbon, name="carbon"),
]